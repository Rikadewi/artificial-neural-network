from mlp import MultiLayerPerceptron


mlp = MultiLayerPerceptron()

mlp.printModel()